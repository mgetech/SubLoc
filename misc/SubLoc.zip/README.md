# Usage:
It is strongly recommended that main.ipynb is opened and run on a GPU equipped system such as [Google Colab](https://colab.research.google.com/).
