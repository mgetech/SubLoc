# Usage:
It is strongly recommended that main.ipynb is opened and run on a GPU equipped system such as https://colab.research.google.com/.
