# Usage:
It is strongly recommended that main.ipynb is opened and run on a GPU equipped system such as [Google Colab](https://colab.research.google.com/).

Note: This code is based on the previous work by [LantaoYu](https://github.com/LantaoYu/SeqGAN)  and [1073521013](https://github.com/1073521013/PSL-DL/tree/master/PSL_GAN). Many thanks to [LantaoYu](https://github.com/LantaoYu)  and [1073521013](https://github.com/1073521013/).
